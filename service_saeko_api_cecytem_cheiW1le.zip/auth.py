import time
import hashlib
import requests
import jwt  # PyJWT
import json
from datetime import datetime


# ============================================================
# CONFIGURACIÓN: RELLENA ESTOS DATOS CON TU SERVICE ACCOUNT
# ============================================================

SERVICE_ACCOUNT = {
    "auth_url": "https://app.saeko.io/oauth/token",
    "api_url": "https://app.saeko.io",
    "client_id": "437188e6943529ac4cccb6b0ef7a7c47c5d48274a37dfcd40c775890433d3ad1",
    "private_key_id": "9f81f00242abedf8d910bedc4e12a0be7468a783",
    "private_key": """-----BEGIN RSA PRIVATE KEY-----
MIIEpgIBAAKCAQEAwcO/r1RH+WeNgmrhsWScxYEnfa4DdedS1/k8PsE3i3hwBDIC
sua3FvOenjOqcOxKWrfWLIeu5jYSqD+rzmsdBvg0kil85fguyrklg/IzQi9lkJJg
KqQXRvXQDtfNwzDP3OkXRGQ5NrxQMpa9YPTx28lKKdKrolP/GD3nMT9hNMHW7iKM
99o1FNOfckIWc3V9ukHd5AMyT6QqA4PiivjH5ikuM61UGwEIhUsb5U6ti8WoC/VM
0ZD54oGP3MaPF/xk0lgYUu96WF2YXUufU+G/jSGVLieG9XjTu7PxcPyuvpzxrtBS
7mkn+hOXcR/rlNuV5ZI9mEY4/j50HtASJg9IkwIDAQABAoIBAQCp+2Sslh5yAFMX
J1aJPb9+UHhpe//TLjTx/NbKIszskKKMO6c8dMQH4X60QJT0bYYpIX9FH17i3Grv
qLO66SLU22ebFcRZJqk99MChiRdIp7XM52xv2/YDrV9xtgXvh2HC5cUgnV/H0dn1
F2JZrWiDrIlgOU2SoWd3R88K2BQZp65rQRbdwibtlzpAYhp8bgkWLiyhA6rNda5k
ph4szYGn991Tn+H8xyj5IMCXP0CjKn9bTMEYliSoynHekYtg5w3aYZ4Fb5py+24P
Y4TFcAELu6smxcSPpi5+Hno6q2mLSsqZVDXyuYypaIDJWTR89T3RSIzky2A1Phjg
cp3H49MpAoGBAPaqxTYh270F52Vw59Rv5MIRYfnwFGf7JsMURmzhC1NjdPZR825Q
aXTHJYMNaiQgzd6LlkQStBMX6Gh/8DhQS5IVT1qac95xECyrRC455T3lcpmihheQ
qoEV3i6N/Ou1We0r/FaOV0+TWDuTd22wQUv11s1giWewhuxdyNciCsldAoGBAMkY
kBYVz21sAY9saFsSScWzF6cUNY3BNayHbVu32SGBX++bhzWqa6phC9beooRSc16z
EuU5h5qtTan3F0KDhIh6gQeId2f5LRklt4qjVfkFJ/14s9UPj1IbkKB5uHx9GQLc
7fvodEVYmSSwPrWWOij+MEJPBimn9EzosNsQ+gqvAoGBAJt6ZpZJXzVVLFavhSFN
aja9ODGPl303PGaIOB/W9gmYzheY7kThYKdgA5AIe5fMKZeWCqBb3a+PSUndIrCM
RCYPUpZ8dn6Ga7iMN4yfp5SNNOAMJlNiN2boPsS/cOWtyMILEKIKVJRu/pWGzSeR
iobzrXKE3/dAuLryHm8kIQJtAoGBALNyudEbcVhhkxrbUFxEe5Rx9l9gB1IR4cWt
rAa2jon5mxSEIyneg+ksZJY/YaLWuKD/B5OJvNpoX++V0SnHltL7Dn0caAFeN8JD
CAAtNSDcWw0zUraEBg7tDihFtj1QnKsTX0L18huXrkExDSSZhBjki0gAoK03dSfU
VU2HXrl9AoGBAPSXdYS9BXtR1kPrbj9dAZ/6+d/rCAwHBFXcHuokYVj3kAduzXIC
g7vUb+jmqzObSfP6Dn7mZtci0RC6CSb+Yjx3f/of9Th6gwdC5aSgJz0dNTNCGeM3
m/lzC6NGL8NyQMUeKgFIwTajIUbwtgt+4QmuOXPw+FsSBnkBtjc8bQ9N
-----END RSA PRIVATE KEY-----
""",
    "expires_at": "2029-02-13T01:45:47Z",
}

# Usuario al que se delega autoridad (debe existir en Saeko)
USER_EMAIL = "api@cecytem.edu.mx"


def build_jwt(service_account: dict, user_email: str) -> str:
    """
    Construye y firma el JWT con RS256 siguiendo la documentación de Saeko.
    payload:
      iss: client_id
      sub: user_email
      scope: "admin"
      iat: timestamp_epoch
      jti: MD5(f"{private_key_id}:{timestamp_epoch}")
    """
    client_id = service_account["client_id"]
    private_key_id = service_account["private_key_id"]
    private_key = service_account["private_key"]

    timestamp_epoch = int(time.time())
    jti_raw = f"{private_key_id}:{timestamp_epoch}".encode("utf-8")
    jti = hashlib.md5(jti_raw).hexdigest()

    payload = {
        "iss": client_id,
        "sub": user_email,
        "scope": "admin",
        "iat": timestamp_epoch,
        "jti": jti,
    }

    token = jwt.encode(
        payload,
        private_key,
        algorithm="RS256",
        headers={
            "typ": "JWT",
            "alg": "RS256",
        },
    )

    # En PyJWT>=2, jwt.encode devuelve str; en versiones viejas, bytes.
    if isinstance(token, bytes):
        token = token.decode("utf-8")

    return token


def get_access_token(service_account: dict, user_email: str) -> dict:
    """
    Pide el access_token al auth server de Saeko usando el JWT.
    Devuelve el JSON completo de la respuesta (incluye access_token, refresh_token, etc.).
    """
    auth_url = service_account["auth_url"]
    assertion_jwt = build_jwt(service_account, user_email)

    body = {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion": assertion_jwt,
    }

    headers = {
        "Content-Type": "application/json",
    }

    resp = requests.post(auth_url, json=body, headers=headers, timeout=30)

    if resp.status_code != 200:
        raise RuntimeError(
            f"Error al obtener access_token: {resp.status_code} {resp.text}"
        )

    return resp.json()


def refresh_access_token(service_account: dict, refresh_token: str) -> dict:
    """
    Refresca el access_token usando el refresh_token, según la doc de Saeko:
    POST /oauth/token
    {
      "refresh_token": "...",
      "scope": "admin",
      "grant_type": "refresh_token"
    }
    """
    auth_url = service_account["auth_url"]

    body = {
        "refresh_token": refresh_token,
        "scope": "admin",
        "grant_type": "refresh_token",
    }

    headers = {
        "Content-Type": "application/json",
    }

    resp = requests.post(auth_url, json=body, headers=headers, timeout=30)

    if resp.status_code != 200:
        raise RuntimeError(
            f"Error al refrescar access_token: {resp.status_code} {resp.text}"
        )

    return resp.json()


def list_schools(service_account: dict, access_token: str) -> dict:
    """
    Llama al endpoint GET /api/v1/core/schools para validar que el token funciona.
    """
    api_url = service_account["api_url"].rstrip("/")
    url = f"{api_url}/api/v1/core/schools"

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json; charset=utf-8",
    }

    resp = requests.get(url, headers=headers, timeout=30)

    if resp.status_code != 200:
        raise RuntimeError(
            f"Error al listar schools: {resp.status_code} {resp.text}"
        )

    return resp.json()


def save_tokens_to_file(token_data: dict, filename: str = "tokens.txt"):
    """
    Guarda los tokens de autenticación en un archivo de texto.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    with open(filename, "w", encoding="utf-8") as f:
        f.write(f"=== TOKENS DE AUTENTICACIÓN SAEKO ===\n")
        f.write(f"Generado: {timestamp}\n")
        f.write(f"{'='*50}\n\n")
        
        f.write(f"ACCESS TOKEN:\n{token_data.get('access_token', 'N/A')}\n\n")
        
        if token_data.get('refresh_token'):
            f.write(f"REFRESH TOKEN:\n{token_data.get('refresh_token')}\n\n")
        
        f.write(f"TOKEN TYPE: {token_data.get('token_type', 'N/A')}\n")
        f.write(f"EXPIRES IN: {token_data.get('expires_in', 'N/A')} segundos\n")
        f.write(f"SCOPE: {token_data.get('scope', 'N/A')}\n\n")
        
        f.write(f"{'='*50}\n")
        f.write(f"Datos completos (JSON):\n")
        f.write(json.dumps(token_data, indent=2, ensure_ascii=False))
    
    print(f"\n✓ Tokens guardados en: {filename}")


def main():
    # 1) Obtener access_token inicial
    print("Obteniendo access_token inicial...")
    token_data = get_access_token(SERVICE_ACCOUNT, USER_EMAIL)
    access_token = token_data["access_token"]
    refresh_token = token_data.get("refresh_token")
    expires_in = token_data.get("expires_in")

    print(f"access_token: {access_token[:40]}...")  # solo para debug
    print(f"expires_in: {expires_in} segundos")
    if refresh_token:
        print(f"refresh_token: {refresh_token[:40]}...")

    # Guardar tokens en archivo
    save_tokens_to_file(token_data)

    # 2) Probar una llamada a la API de Saeko
    print("\nLlamando a /api/v1/core/schools ...")
    schools = list_schools(SERVICE_ACCOUNT, access_token)
    print("Respuesta de /schools:")
    print(schools)

    # 3) Ejemplo opcional de refresh del token (solo si tienes refresh_token)
    if refresh_token:
        print("\nRefrescando el token...")
        refreshed = refresh_access_token(SERVICE_ACCOUNT, refresh_token)
        new_access_token = refreshed["access_token"]
        print(f"Nuevo access_token: {new_access_token[:40]}...")
        
        # Guardar tokens refrescados
        save_tokens_to_file(refreshed, "tokens_refreshed.txt")


if __name__ == "__main__":
    main()
